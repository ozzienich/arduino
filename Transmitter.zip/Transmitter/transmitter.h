#ifndef TRANSMITTER_H
#define TRANSMITTER_H

#include <Arduino.h>

namespace trans {
  struct Point {
    uint8_t x;
    uint8_t y;
  };

  typedef const Point (*processorFcnPtr)();   // function pointer definition
  const static uint8_t msgLen = 7;            // rubbish + synchro + src + dest + data[1] + data[2] + checksum
}

class Transmitter
{
public:
  Transmitter() = delete;                           // remove default constructor with no parameters
  Transmitter(const Transmitter&) = delete;            // non construction copyable
  Transmitter& operator=(const Transmitter&) = delete; // non-copyable
  Transmitter(uint8_t localAddr, uint8_t destAddr, uint16_t freq = 10);
  void      beginSerial(uint16_t baudRate = 1200);  // Serial cannot be called outside of setup/loop so we use another function to begin serial
  uint8_t   getDestAddr();                          // receiver address
  void      setDestAddr(uint8_t destAddr);          // receiver address
  uint8_t   getAddr();                              // own address
  void      setAddr(uint8_t addr);                  // own address
  uint16_t  getTransFreq();
  void      setTransFreq(uint16_t freq);
  void      transmitFcnOutput(trans::processorFcnPtr fcnPtr);

private:
  void enableInterrupt();
  void disableInterrupt();

  uint16_t m_frequency;       // frequency of checking the Serial buffer in Hertz
  uint16_t m_prescaler;       // prescaler for out interrupt clock
  uint16_t m_matchCounter;    // counter to match for interrupt serial buffer
  uint8_t  m_msgBuffer[trans::msgLen];    // buffer to contain the message to send
};

#endif
