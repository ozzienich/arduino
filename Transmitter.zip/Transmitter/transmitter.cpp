#include "transmitter.h"

namespace trans {
  const static uint8_t synchroByte = 0xFF;         // our message shall not contain 0xFF (255)
  volatile static bool isTimeToSend = false;       // variable to check against for reading serial buffer
}

Transmitter::Transmitter(uint8_t localAddr,
                         uint8_t destAddr,
                         uint16_t freq)
{
  m_frequency = freq;
  m_msgBuffer[0] = 0x00;                // rubbish byte to improve send success rate
  m_msgBuffer[1] = trans::synchroByte;  // byte to search for for the start of message
  m_msgBuffer[2] = localAddr;
  m_msgBuffer[3] = destAddr;
  trans::isTimeToSend = false;

  if (freq != 0)
  {
    setTransFreq(freq);
  }
}

void Transmitter::beginSerial(uint16_t baudRate)
{
  if (m_frequency == 0)
  {
    uint8_t bitsPerSend = 8 * trans::msgLen;
    setTransFreq(static_cast<int>(baudRate * 0.9) / bitsPerSend); // send at 90% of maximum capability
  }
  Serial.begin(baudRate);
  while (!Serial);
}

uint8_t Transmitter::getAddr()
{
  return m_msgBuffer[2];
}

void Transmitter::setAddr(uint8_t addr)
{
  m_msgBuffer[2] = addr;
}

uint8_t Transmitter::getDestAddr()
{
  return m_msgBuffer[3];
}

void Transmitter::setDestAddr(uint8_t addr)
{
  m_msgBuffer[3] = addr;
}

uint16_t Transmitter::getTransFreq()
{
  return m_frequency;
}

void Transmitter::setTransFreq(uint16_t freq)
{
  m_frequency = freq;
  if (freq < 4)
  {
    m_prescaler = 256;              // set prescaler of 256 --> 62.5kHz frequency, every counter step is 16us
    m_matchCounter = (uint16_t)((1000000 / (16 * freq)) - 1);     // minus 1 because counter starts from 0
  }
  else
  {
    m_prescaler = 64;               // set prescaler of 64 --> 250kHz frequency, every counter step is 4us
    m_matchCounter = (uint16_t)((1000000 / (4 * freq)) - 1);     // minus 1 because counter starts from 0
  }
}

void Transmitter::transmitFcnOutput(trans::processorFcnPtr fcnPtr)  // pointer to the function that the user wants to call to process data
{
  enableInterrupt();

  while (true)      // blocking call. program will never exit this loop
  {
    const trans::Point data = fcnPtr();
    m_msgBuffer[4] = data.x;
    m_msgBuffer[5] = data.y;

    uint16_t totalSum = 0;
    for (uint8_t i = 2; i < trans::msgLen - 1; i++)     // sum localAddr, destAddr, data[1], data[2]
    {
        totalSum += m_msgBuffer[i];
    }

    while (totalSum > 255)    // more than 1 byte
    {
      uint8_t leftByte = totalSum >> 8;
      uint8_t rightByte = totalSum & 0xFF;
      totalSum = leftByte + rightByte;
    }

    uint8_t checksum;
    if (totalSum == trans::synchroByte)    // checksum cannot be equal to synchroByte
    {
      checksum = 0xC9;                     // let checksum = 0xC9 (201) when they are equal (no special reason for this number)
    }
    else
    {
      checksum = totalSum;
    }

    m_msgBuffer[6] = checksum;

    if (trans::isTimeToSend)
    {
      Serial.write(m_msgBuffer, trans::msgLen);
      trans::isTimeToSend = false;
    }
  }

  disableInterrupt();
}

void Transmitter::enableInterrupt()
{
  uint8_t oldSREG = SREG;
  cli();                    // disable interrupt
  TCCR1A = 0;               // normal counting mode
  switch (m_prescaler)
  {
  case 64:
    TCCR1B = _BV(CS11) | _BV(CS10);     // set prescaler of 64 --> 250kHz frequency, every counter step is 4us
    break;
  case 256:
    TCCR1B = _BV(CS12);                 // set prescaler of 256 --> 62.5kHz frequency, every counter step is 16us
    break;
  }
  TCCR1B |= _BV(WGM12);       // turn on CTC mode
  TCNT1 = 0;                  // clear the timer count
  OCR1A = m_matchCounter; // counter to match with for interrupt
  TIFR1 |= _BV(OCF1A);        // clear any pending interrupts;
  TIMSK1 |=  _BV(OCIE1A);     // enable the output compare timer interrupt (interrupts globally enabled too)
  SREG = oldSREG;             // recall initial state
}

void Transmitter::disableInterrupt()
{
  uint8_t oldSREG = SREG;
  cli();                              // disable interrupt
  TCCR1B = _BV(CS11) | _BV(CS10);     // set prescalar back to 64 (default value)
  TCNT1 = 0;                          // clear the timer count
  TIFR1 |= _BV(OCF1A);                // clear any pending interrupts;
  TIMSK1 &=  ~_BV(OCIE1A);            // disable timer 1 output compare interrupt
  SREG = oldSREG;                     // recall initial state
}

ISR(TIMER1_COMPA_vect)
{
  // if it is time to check, we check
  // otherwise, it means that reading the serial buffer took too long,
  // so we skip the round
  if (!trans::isTimeToSend)
    trans::isTimeToSend = true;
}
