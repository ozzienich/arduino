#ifndef		_KEY_H
#define		_KEY_H

#include "define.h"
//====================================================================
#define		NO_KEY	0
#define		KEY1	1
#define		KEY2	2
#define		KEY3	3
#define		KEY4	4
//====================================================================
extern unsigned char ucBuff_tx[];
extern unsigned char ucFlag_System;
//====================================================================
void ScanKeyInTcc();
void DoKey(void);
//====================================================================
#endif