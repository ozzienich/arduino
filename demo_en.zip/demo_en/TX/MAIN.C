#include <pic.h>
#include "define.h"
#include "ask_tx.h"
#include "key.h"

unsigned int uiTime=0,uiSendNum=0;
unsigned char ucBuff_tx[5]={0};
unsigned char ucFlag_System=0;
							//bit0 : waiting for data process
							//bit1:	packet send end
							//bit2:	data transmiting
							//bit3: key pressed
							//bit4
							//bit5
							//bit6
							//bit7

//IO function set
void port_init(void)
{
	OPTION_REG=0;
	ANSEL=0X00;
	ANSELH=0X00;
	WPUA=0XFF;
	IOCA=0X00;
	TRISA=0X07;
	TRISC=0Xc0;
	PORTC=0X00;
	TRISB=0X00;
	WPUB=0X00;
	IOCB=0X00;
}

void timer1_init(void)
{
	T1CON = 0x01; // 8M/4/1
	TMR1IE = 1;
	TMR1L = 0x22;	 //500us
	TMR1H = 0xFC;
}

void interrupt ISR_timer(void)
{
	if(TMR1IF)
   	{
   		
   		TMR1L = 0x22;	 //500us
		TMR1H = 0xFC;	
    	TMR1IF=0;
		ScanKeyInTcc();
		if(ucFlag_System&0x04)	// need to send data
		{
			SendData_ASK_InTCC();
			if(ucFlag_System&0x02)	// packet send end
			{
				ucFlag_System&=0xf9;
				uiSendNum++;
			}
		}
		else
		{
			P_ASK_DATA=0;
		}
		uiTime++;
		if(uiTime==2000)	//1s
		{
			uiTime=0;
			if(MODE_TIME)	// timing mode
			{
				ucFlag_System|=0x01;
				ucBuff_tx[3]=0x00;
			}
		}
	}	
} 
void delay(unsigned int data)
{
	unsigned char i;
	for(;data!=0;data--)
	{
		for(i=0;i<250;i++);
	}
}
void DoData(void)
{
	ucBuff_tx[4]=(unsigned char)(ucBuff_tx[0]+ucBuff_tx[1]+ucBuff_tx[2]+ucBuff_tx[3]);
	ucFlag_System|=0x04;
}
void main(void)
{
	OSCCON = 0X70;	// 8M crystal
	WDTCON = 0X00;//disable wdt
	port_init();


	timer1_init();
	INTCON = 0xc0;		// enable interrupt
	ucBuff_tx[0]=0x55;
	ucBuff_tx[1]=0x00;
	ucBuff_tx[2]=0xff;
	ucBuff_tx[3]=0x00;
	ucBuff_tx[4]=0xaa;

	while(1)
	{
		DoKey();
		if(ucFlag_System&0x01)	//waiting for data process
		{
			DoData();
			ucFlag_System&=0xfe;
		}
	}
}