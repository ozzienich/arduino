#include"key.h"
static unsigned char ucKeyCnt=0;
//ucKeyLast=0,ucKeyValu=0,,ucKeyValuTemp=0

void ScanKeyInTcc()
{
	if((KEY1_DOWN)||(KEY2_DOWN)||(KEY3_DOWN)||(KEY4_DOWN))
	{
		if(ucKeyCnt!=200)	
		{
			ucKeyCnt++;
			if(ucKeyCnt==10)	
			{
				ucFlag_System|=0x08;	
			}
		}
	}
	else
	{
		ucKeyCnt=0;
	}
}

void DoKey(void)
{
	if(ucFlag_System&0x08)	// key pressed
	{
		if(KEY1_DOWN)
		{
			ucBuff_tx[3]=KEY1;
			ucFlag_System|=0x01;
		}
		else if(KEY2_DOWN)
		{
			ucBuff_tx[3]=KEY2;
			ucFlag_System|=0x01;
		}
		else if(KEY3_DOWN)
		{
			ucBuff_tx[3]=KEY3;
			ucFlag_System|=0x01;
		}
		else if(KEY4_DOWN)
		{
			ucBuff_tx[3]=KEY4;
			ucFlag_System|=0x01;
		}
		else
		{
			//ucBuff_tx[3]=KEY1;
			//ucFlag_System|=0x01;
		}
		ucFlag_System&=0xf7;	// clear flag of key pressed
	}
}