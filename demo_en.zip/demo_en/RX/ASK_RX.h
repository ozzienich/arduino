#ifndef		_ASK_RX_H
#define 	_ASK_RX_H

#include 	"define.h"
//===============================================
//ָ��궨��

//===============================================
//===============================================
//��������
#define		ASK_DATA_BYTE	5//length of packet
#define		BIT_TMAX		10// max interval of one bit(unit of 125us)
#define		BIT_TMIN		6//min interval of one bit(unit of 125us)

#define		BIT_HALF_TMAX	6// max interval of half bit
#define		BIT_HALF_TMIN	2//min interval of half bit

#define		RX_I_MAX		150// 0.5ms delay for 2M system clock
#define		RX_DATA_END		ucFlagSystem|=0x02//packet receive OK
//===============================================
//�ⲿ����������
extern unsigned char ucBuffRx[];//data byf



extern void timer1_init(void);	//sample of 125us init
#define		InitRxTcc()		timer1_init()
//===============================================
//��������
void RxData_InTCC(void);// data sampling
void RxDataStart(void);// recognize the header of packet
//===============================================
#endif