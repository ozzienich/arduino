#include"ask_rx.h"

unsigned char ucTimeRX=0,ucStartCnt=0,ucTempRx=0,ucHeadCnt=0,ucBitRx=0,ucByteRx=0;
unsigned char ucFlagRx=0;	// rx flag
							//bit0: last status of P_ASK_DATA PIN
							//bit1: start of date
							//bit2:	receive correct header
							//bit3:	the init flag of rx data is error
							//bit4:
							//bit5:
							//bit6:
							//bit7:	packet receive OK
static void RxDataHead(void)
{
	if(ucFlagRx&0x01)
	{
		if(ucHeadCnt)
	{
		ucHeadCnt=0;
		ucFlagRx=0;
	}
		}		
		else
		{
			ucHeadCnt++;
			if(ucHeadCnt==4)
			{
				ucHeadCnt=0;
				ucFlagRx|=0x04;
//test:header
				ucBitRx=0;
				ucByteRx=0;
			}
		}
	}

static void RxDataBuff(void)
{
	ucTempRx=ucTempRx<<1;
	if(ucFlagRx&0x01)
	{
		ucTempRx|=0x01;
	}
	else
	{
		ucTempRx&=0xfe;
	}
	if(ucBitRx==8)
	{
		ucBitRx=0;
		ucBuffRx[ucByteRx]=ucTempRx;
		ucByteRx++;
		if(ucByteRx==ASK_DATA_BYTE)
		{
			ucByteRx=0;
			ucFlagRx=0x80;
			RX_DATA_END;
//test:packet receive OK
		}
	}
}
static void CorrectRxTime(void)
{
	unsigned char i=0;
	if(ucFlagRx&0x01)
	{
		while(P_ASK_DATA)
		{
			i++;
			if(i==RX_I_MAX)
			{
				ucFlagRx=0;
				break;
			}
		}
	}
	else
	{
		while(!(P_ASK_DATA))
		{
			i++;
			if(i==RX_I_MAX)
			{
				ucFlagRx=0;
				break;
			}
		}
	}
//test: adjustment of sampling point 
	InitRxTcc();
	ucTimeRX=2;
}
void RxData_InTCC(void)
{
	ucTimeRX++;
	if((ucFlagRx&0x02)&&(ucTimeRX==8))
	{
//test: point of sampling
		if(P_ASK_DATA)
		{
			ucFlagRx|=0x01;
		}
		else
		{
			ucFlagRx&=0xfe;
		}
		ucTimeRX=0;
		ucBitRx++;
		if(ucFlagRx&0x04)
		{
			RxDataBuff();
		}
		else
		{
			RxDataHead();
		}
		if(!(ucFlagRx&0x80))
		{
			CorrectRxTime();
		}
	}
}

void RxDataStart(void)	// judgment of data start
{
	if(!(ucFlagRx&0x02))
	{
		if(P_ASK_DATA)
		{
			if(!(ucFlagRx&0x01))
			{
	
				ucFlagRx|=0x01;
				if((ucTimeRX>=BIT_TMIN)&&(ucTimeRX<=BIT_TMAX))
				{
	
					ucTimeRX=0;
					ucStartCnt++;
					if(ucStartCnt==5)
					{
						ucStartCnt=0;
							while(P_ASK_DATA)
							{
							if(ucTimeRX>BIT_HALF_TMAX)
								{
									ucFlagRx|=0x08;
									break;
								}
							}
						if(!(ucFlagRx&0x08))
						{
							while(!(P_ASK_DATA))
							{
								if(ucTimeRX>BIT_TMAX)
								{
									ucFlagRx|=0x08;
									break;
								}
							}
						}
						if(ucFlagRx&0x08)
						{
							ucFlagRx=0;
						}
						else
						{
							ucTimeRX=6;
							ucFlagRx=0x02;
							ucBitRx=0;
//test: start of date
							InitRxTcc();
						}
					}	
				}
				else
				{
					ucStartCnt=0;
					ucTimeRX=0;
				}
			}
		}
		else
		{
			if(ucFlagRx&0x01)
			{
				ucFlagRx&=0xfe;
				if(ucTimeRX>BIT_HALF_TMAX)
				{
					ucStartCnt=0;
				}
			}
		}
	}
}