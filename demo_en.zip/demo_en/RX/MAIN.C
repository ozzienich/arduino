#include <pic.h>
#include "define.h"
#include "ask_rx.h"

unsigned char ucBuffRx[ASK_DATA_BYTE]={0};
unsigned int uiDataNum=0;
unsigned int uiTempRxData=0;
unsigned char ucFlagSystem=0;	//system flag
								//bit0:
								//bit1:packet receive end
								//bit2:packet check OK
								//bit3:packet correct and process OK
								//bit4:
								//bit5:
								//bit6:
								//bit7:

//IO function set
void port_init(void)
{
	OPTION_REG=0;
	ANSEL=0X00;
	ANSELH=0X00;
	WPUA=0XFF;
	IOCA=0X00;
	TRISA=0x07;
	PORTA=0X00;

	WPUB=0X00;
	IOCB=0X00;
	TRISB=0X60;
	PORTB=0X00;

	TRISC=0X00;
	PORTC=0X1F;
}

void timer1_init(void)
{
	T1CON = 0x01; // 8M/4/1
	TMR1IE = 1;
	TMR1L = 0x1a;	 //125us
	TMR1H = 0xFF;
	TMR1IF=0;
}

void interrupt ISR_timer(void)
{
	if(TMR1IF)
   	{
   		TMR1L = 0x1a;	 //125us
		TMR1H = 0xFF;	
    		TMR1IF=0;
		RxData_InTCC();

	}
} 
void delay(unsigned int data)
{
	unsigned char j;
	for(;data!=0;data--)
	{
		for(j=0;j<250;j++);
	}
}

void DoData(void)
{
		switch(ucBuffRx[3])
		{
			case 0x00:
				LED_TIME_K;
				LED_KEY1_G;
				LED_KEY2_G;
				LED_KEY3_G;
				LED_KEY4_G;
				uiDataNum++;
				break;
			case 0x01:
				LED_TIME_G;
				LED_KEY1_K;
				LED_KEY2_G;
				LED_KEY3_G;
				LED_KEY4_G;
				uiDataNum++;
				break;
			case 0x02:
				LED_TIME_G;
				LED_KEY1_G;
				LED_KEY2_K;
				LED_KEY3_G;
				LED_KEY4_G;
				uiDataNum++;
				break;
			case 0x03:
				LED_TIME_G;
				LED_KEY1_G;
				LED_KEY2_G;
				LED_KEY3_K;
				LED_KEY4_G;
				uiDataNum++;
				break;
			case 0x04:
				LED_TIME_G;
				LED_KEY1_G;
				LED_KEY2_G;
				LED_KEY3_G;
				LED_KEY4_K;
				uiDataNum++;
				break;
			default:
				break;
		}
	//dis_data(uiDataNum);
}
void main(void)
{
	OSCCON = 0X70;	// 8M crystal
	WDTCON = 0X00;//disable wdt
	port_init();

	timer1_init();
	INTCON = 0xc0;		// enable interrupt
	ASK_CS_EN;
	//dis_data(uiDataNum);
	while(1)
	{

		RxDataStart();
	
		if(ucFlagSystem&0x02)
		{
			DoData();
			ucFlagSystem&=0xfd;
			delay(200);
		}

	}
}