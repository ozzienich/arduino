#include "receiver.h"

namespace recv {
  const static uint8_t msgSize = 5;                // message is 5 bytes long (srcAddr, destAddr, data[1], data[2], checksum)
  const static uint8_t synchroByte = 0xFF;         // our message shall not contain 0xFF (255)
  volatile static bool isTimeToCheck = false;      // variable to check against for reading Serial buffer
}

Receiver::Receiver(uint8_t localAddr,
                   uint8_t srcAddr,
                   uint16_t freq)
{
  m_frequency = freq;
  m_localAddr = localAddr;
  m_srcAddr = srcAddr;
  recv::isTimeToCheck = false;

  if (freq != 0)
    setRecvFreq(freq);
}

void Receiver::beginSerial(uint16_t baudRate)
{
  Serial.begin(baudRate);
  while (!Serial);          // waits for Serial to be ready before proceeding
}

uint8_t Receiver::getSrcAddr()
{
  return m_srcAddr;
}

void Receiver::setSrcAddr(uint8_t addr)
{
  m_srcAddr = addr;
}

uint8_t Receiver::getLocalAddr()
{
  return m_localAddr;
}

void Receiver::setLocalAddr(uint8_t addr)
{
  m_localAddr = addr;
}

uint16_t Receiver::getRecvFreq()
{
  return m_frequency;
}

void Receiver::setRecvFreq(uint16_t freq)
{
  m_frequency = freq;
  if (freq < 4)
  {
    m_prescaler = 256;              // set prescaler of 256 --> 62.5kHz frequency, every counter step is 16us
    m_matchCounter = (uint16_t)((1000000 / (16 * freq)) - 1);     // minus 1 because counter starts from 0
  }
  else
  {
    m_prescaler = 64;               // set prescaler of 64 --> 250kHz frequency, every counter step is 4us
    m_matchCounter = (uint16_t)((1000000 / (4 * freq)) - 1);     // minus 1 because counter starts from 0
  }
}

bool Receiver::receive(uint16_t timeout)
{
  uint32_t oldTime = millis();
  uint32_t newTime = 0;
  bool hasData = false;

  if (m_frequency != 0)
    enableInterrupt();

  while (!hasData)
  {
    if (recv::isTimeToCheck || m_frequency == 0)    // if frequency is 0, always check whenever possible
    {
      while (Serial.available() == 0)   // wait until something is available or timeout
      {
        newTime = millis();
        if ((newTime - oldTime) > timeout)
        {
          goto endOfFunction;
        }
        delay(1);
      }

      while (Serial.read() != recv::synchroByte); // synchronization byte
      {
        newTime = millis();
        if ((newTime - oldTime) > timeout)
        {
          goto endOfFunction;
        }
      }
      while (Serial.available() < recv::msgSize)   // wait till we receive the whole message in the buffer
      {
        newTime = millis();
        if ((newTime - oldTime) > timeout)
        {
          goto endOfFunction;
        }
      }

      if (Serial.read() == m_srcAddr)     // check if message is from the expected transmitter
      {
        if (Serial.read() == m_localAddr)     // check if the message is for us
        {
          m_point.x = Serial.read();
          m_point.y = Serial.read();
          uint16_t totalSum = m_srcAddr + m_localAddr + m_point.x + m_point.y;
          while (totalSum > 255)    // more than 1 byte
          {
            uint8_t leftByte = totalSum >> 8;
            uint8_t rightByte = totalSum & 0xFF;
            totalSum = leftByte + rightByte;
          }

          if (totalSum == recv::synchroByte)    // checksum cannot be equal to synchroByte
          {
            totalSum = 0xC9;                    // let checksum = 0xC9 (201) when they are equal (no special reason for this number)
          }

          if (static_cast<uint8_t>(Serial.read()) == totalSum)       // checksum matches
          {
            hasData = true;
            recv::isTimeToCheck = false;
          }
        }
        else    // message destination not us
        {
          recv::isTimeToCheck = false;
        }
      }
      else    // message source not expected source
      {
        recv::isTimeToCheck = false;
      }
    }
    else    // not time to check for data yet so we check for timeout
    {
      newTime = millis();
      if ((newTime - oldTime) > timeout)
      {
        goto endOfFunction;
      }
    }
  }   // while (!hasData) loop

endOfFunction:
  recv::isTimeToCheck = false;
  if (m_frequency != 0)
    disableInterrupt();

  while (Serial.available())
    Serial.read();    // flush out the buffer so that the next round we get the latest stuff

  return hasData;
}

recv::Point Receiver::getMessage()
{
  return m_point;
}

void Receiver::enableInterrupt()
{
  uint8_t oldSREG = SREG;
  cli();                    // disable interrupt
  TCCR1A = 0;               // normal counting mode
  switch (m_prescaler)
  {
  case 64:
    TCCR1B = _BV(CS11) | _BV(CS10);     // set prescaler of 64 --> 250kHz frequency, every counter step is 4us
    break;
  case 256:
    TCCR1B = _BV(CS12);                 // set prescaler of 256 --> 62.5kHz frequency, every counter step is 16us
    break;
  }
  TCCR1B |= _BV(WGM12);       // turn on CTC mode
  TCNT1 = 0;                  // clear the timer count
  OCR1A = m_matchCounter; // counter to match with for interrupt
  TIFR1 |= _BV(OCF1A);        // clear any pending interrupts;
  TIMSK1 |=  _BV(OCIE1A);     // enable the output compare timer interrupt (interrupts globally enabled too)
  SREG = oldSREG;             // recall initial state
}

void Receiver::disableInterrupt()
{
  uint8_t oldSREG = SREG;
  cli();                              // disable interrupt
  TCCR1B = _BV(CS11) | _BV(CS10);     // set prescalar back to 64 (default value)
  TCNT1 = 0;                          // clear the timer count
  TIFR1 |= _BV(OCF1A);                // clear any pending interrupts;
  TIMSK1 &=  ~_BV(OCIE1A);            // disable timer 1 output compare interrupt
  SREG = oldSREG;                     // recall initial state
}

ISR(TIMER1_COMPA_vect)
{
  // if it is time to check, we check
  // otherwise, it means that reading the Serial buffer took too long,
  // so we skip the round
  if (!recv::isTimeToCheck)
    recv::isTimeToCheck = true;
}
