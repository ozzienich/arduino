#ifndef RECEIVER_H
#define RECEIVER_H

#include <Arduino.h>

namespace recv {
  struct Point {
    uint8_t x;
    uint8_t y;
  };
}

class Receiver
{
public:
  Receiver() = delete;
  Receiver(const Receiver&) = delete;            // non construction copyable
  Receiver& operator=(const Receiver&) = delete; // non-copyable
  Receiver(uint8_t localAddr, uint8_t srcAddr, uint16_t freq = 30);
  void        beginSerial(uint16_t baudRate = 1200);  // Serial1 cannot be called outside of setup/loop so we use another function to begin Serial1
  uint8_t     getSrcAddr();                    // transmitter address
  void        setSrcAddr(uint8_t addr);        // transmitter address
  uint8_t     getLocalAddr();                  // own address
  void        setLocalAddr(uint8_t addr);      // own address
  uint16_t    getRecvFreq();
  void        setRecvFreq(uint16_t freq);
  bool        receive(uint16_t timeout = 100);
  recv::Point getMessage();               // returns a pointer to the message

private:
  void enableInterrupt();
  void disableInterrupt();

  uint16_t    m_frequency;               // frequency of checking the Serial1 buffer in Hertz
  uint8_t     m_localAddr;               // receiver address
  uint8_t     m_srcAddr;                 // transmitter address
  uint16_t    m_prescaler;               // prescaler for out interrupt clock
  uint16_t    m_matchCounter;            // counter to match for interrupt Serial1 buffer
  recv::Point m_point;                   // data points from the transmitter
};

#endif
